const string1 = "tinus"
const string2 = "tinus"

const compareValue = string1.localeCompare(string2)
var s = "tinus";
if (s.match("pin")) {
    console.log("tas")
}
// console.log(s.match(/hello.*/))